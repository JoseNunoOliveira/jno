
import Rel
import Cp
import Probability
import Qais

----------------
dconc :: ([a], [b]) -> [Either a b]
dconc = conc . (map i1 >< map i2)

uconc :: [Either t t1] -> ([t], [t1])
uconc [] = ([],[])
uconc(Left a:x) = (a:l,r) where (l,r)=uconc x
uconc(Right b:x) = (l,b:r) where (l,r)=uconc x

codiag = map (either id id)
----------------
shuf x y = do { ts <- x; ts' <- y; join cup ts ts' }
--where
join :: Monad fF => (fF [a] -> fF [a] -> fF [a]) -> [a] -> [a] -> fF [a]
join op t [] = return t
join op [] t = return t
join op (a:t)(b:p) = op x y where
       x = do { x <- join op t ((b:p)) ; return (a:x) }
       y = do { y <- join op ((a:t)) p ; return (b:y) }

cup a b = set (a++b)
----------------
shufp p x y = do { ts <- x; ts' <- y; otimesp p ts ts' } 

otimesp p = join (mix p)

mix :: ProbRep -> Dist a -> Dist a -> Dist a
mix p d d' = D (x++y) where
      x = map (id><(p*)) (unD d) 
      y = map (id><((1-p)*)) (unD d') 
----------------

seqc :: Monad fM => fM [a] -> fM [a] -> fM [a]
seqc p q = do { t <- p ; v <- q; return (t++v) }

skip = return []

p = ["ab", "xy"]
q = ["12","34"]

